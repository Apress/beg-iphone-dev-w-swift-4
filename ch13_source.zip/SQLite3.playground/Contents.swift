//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var database:COpaquePointer = nil
let result = sqlite3_open("/path/to/database/file", &database)























